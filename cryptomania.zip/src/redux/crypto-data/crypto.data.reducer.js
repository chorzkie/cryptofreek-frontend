import {
    RESET_INIT_FETCH,
    RESET_INIT_FETCH_ALL_CRYPTO,

    FETCH_TOP_CRYPTO_SUCCESS,
    FETCH_TOP_CRYPTO_FAILED,

    FETCH_ALL_CRYPTO_SUCCESS,
    FETCH_ALL_CRYPTO_FAILED,

    FETCH_DETAIL_DATA_SUCCESS,
    FETCH_DETAIL_DATA_FAILED,
}
    from './crypto.data.constants'

import { getCryptoList, getAllCryptoList, prepareCryptoDetailData } from './crypto.data.utils';


const initialStateCryptoData = {
    mainMessage: 'Here are 10 hottest cryptos of the last 24 hours..',
    initFetchDone: false,
    allCryptoFetchDone: false,
    allCrypto: [],
    cryptoToPresent: [],
    fetchingCryptoToPresentDone: false,
    favoriteCrypto: [],
    detailsOfCryptosToPresent: [],
}


export const cryptoDataRED = (state = initialStateCryptoData, action = {}) => {
    switch (action.type) {

        case RESET_INIT_FETCH:
            return Object.assign({}, state, { initFetchDone: false })

        case RESET_INIT_FETCH_ALL_CRYPTO:
            return Object.assign({}, state, { allCryptoFetchDone: false })


        case FETCH_TOP_CRYPTO_FAILED:
            return Object.assign({}, state, { mainMessage: action.payload })

        case FETCH_TOP_CRYPTO_SUCCESS:
            const cryptoList = getCryptoList(action.payload);
            return Object.assign({}, state, { cryptoToPresent: cryptoList, initFetchDone: true, fetchingCryptoToPresentDone: true });


        case FETCH_ALL_CRYPTO_FAILED:
            return Object.assign({}, state, { mainMessage: action.payload })

        case FETCH_ALL_CRYPTO_SUCCESS:
            const allCryptoList = getAllCryptoList(action.payload)
            return Object.assign({}, state, { allCrypto: allCryptoList, allCryptoFetchDone: true })


        case FETCH_DETAIL_DATA_FAILED:
            return Object.assign({}, state, { mainMessage: action.payload })

        case FETCH_DETAIL_DATA_SUCCESS:
            const cryptoDetailData = prepareCryptoDetailData(action.payload);
            return Object.assign({}, state, { detailsOfCryptosToPresent: [...state.detailsOfCryptosToPresent, cryptoDetailData] });

        default:
            return state;
    }
}

