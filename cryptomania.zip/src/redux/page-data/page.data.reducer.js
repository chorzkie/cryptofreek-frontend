import {
    SET_MAIN_MESSAGE,

    SIGN_UP_PENDING,
    SIGN_UP_SUCCESS,
    SIGN_UP_FAILED,

    SIGN_IN_PENDING,
    SIGN_IN_SUCCESS,
    SIGN_IN_FAILED,
}
    from './page.data.constants'


const initialStatePageData = {
    displayName: '',
    isLoggedin: false,
    mainMessage: '',
    signInSignUpMessage: '',
}

export const pageDataRED = (state = initialStatePageData, action = {}) => {
    switch (action.type) {

        case SET_MAIN_MESSAGE:
            return Object.assign({}, state, { mainMessage: action.payload })

        // case CHANGE_EMAIL_REG:
        //     return Object.assign({}, state, { email: action.payload })
        // case CHANGE_PASSWORD_REG:
        //     return Object.assign({}, state, { password: action.payload })

        // case REGISTER_PENDING: //registeringMessage: 'Registering...'
        //     return Object.assign({}, state, { registeringMessage: '', isPending: true })
        // case REGISTER_FAILED:
        //     return Object.assign({}, state, { registeringMessage: action.payload, isPending: false })

        default:
            return state;
    }
}