import {
    SET_MAIN_MESSAGE,

    SIGN_UP_PENDING,
    SIGN_UP_SUCCESS,
    SIGN_UP_FAILED,

    SIGN_IN_PENDING,
    SIGN_IN_SUCCESS,
    SIGN_IN_FAILED,
}
    from './page.data.constants'


    export const setMainMessageACT = (text) => ({
        type: SET_MAIN_MESSAGE,
        payload: text
    })