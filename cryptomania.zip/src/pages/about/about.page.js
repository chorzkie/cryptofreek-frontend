import React from 'react'



const AboutPage = () =>{
    return (
        <div>
            <h3>About Page</h3>
        </div>
    )
}

export default AboutPage;
