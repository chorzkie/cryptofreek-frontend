import React, { Component } from 'react'



export class SignInAndSignUpPage extends Component {
    render() {
        return (
            <div>
                <h3>Sign In And Sign Up</h3>
            </div>
        )
    }
}

export default SignInAndSignUpPage