
export const getCryptoList = (anyCryptos) => {
    if (anyCryptos.Message !== "Success") {
        return []
    }
    const nameOnly = anyCryptos.Data.map(eachCrypto => {
        const aCrypto = {id: eachCrypto.CoinInfo.Id, name: eachCrypto.CoinInfo.Name }
        return aCrypto
    })

    return nameOnly;
}