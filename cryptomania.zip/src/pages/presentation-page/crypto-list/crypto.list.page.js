import React, { Component } from 'react';
import Card from '../../../components/crypto-info/card.component';
import { connect } from 'react-redux'
import { fetchTopCryptoACT, fetchAllCryptoACT, getCryptoDetailsToPresentACT, fetchDetailDataACT } from '../../../redux/crypto-data/crypto.data.actions';

// import { getCryptoList } from '../presentation.utils';
// import topCrypto from '../../../dataSource/topCrypto';

import './crypto-list.styles.scss'


const mapStateToProps = (state) => {
    return {
        initFetchDone: state.cryptoDataRED.initFetchDone,
        allCryptoFetchDone: state.cryptoDataRED.allCryptoFetchDone,
        cryptoToPresent: state.cryptoDataRED.cryptoToPresent,
        detailsOfCryptosToPresent: state.cryptoDataRED.detailsOfCryptosToPresent,
        fetchingCryptoToPresentDone: state.cryptoDataRED.fetchingCryptoToPresentDone,
    }
}

const mapDispatchToProps = (dispatch) => {
    return {
        fetchTopCrypto: () => dispatch(fetchTopCryptoACT()),
        fetchAllCrypto: () => dispatch(fetchAllCryptoACT()),
        fetchDetailDataACT: () => dispatch(fetchDetailDataACT()),
        getCryptoDetailsToPresent: () => dispatch(getCryptoDetailsToPresentACT()),
    }
}


export class CryptoListPage extends Component {
    // constructor() {
    //     super();
    //     this.state = {
    //         cryptoToView: []
    //     }
    // }


    render() {
        const { detailsOfCryptosToPresent } = this.props;

        return (
            <div>
                {detailsOfCryptosToPresent === [] ?
                    (<div> <h3>Loading data...</h3> </div>)
                    :
                    (<div className='each-card'>
                        {detailsOfCryptosToPresent
                            .map(eachCrypto => (
                                <Card key={eachCrypto.id} details={eachCrypto} />
                            ))}
                    </div>)
                }
            </div>
        )
    }

    componentDidMount() {

        const { initFetchDone,
            allCryptoFetchDone,
            fetchTopCrypto,
            fetchAllCrypto,
            cryptoToPresent,
            fetchingCryptoToPresentDone,
            fetchDetailDataACT,
            getCryptoDetailsToPresent } = this.props;

        if (initFetchDone === false) {
            fetchTopCrypto();
        }

        if (allCryptoFetchDone === false) {
            fetchAllCrypto();
        }


        setTimeout(() => getCryptoDetailsToPresent(), 5000);

    }
}

export default connect(mapStateToProps, mapDispatchToProps)(CryptoListPage)
