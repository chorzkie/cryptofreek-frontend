import React, { Component } from 'react';
import Card from '../../../components/crypto-info/card.component';
import { getCryptoList } from '../presentation.utils';

import topCrypto from '../../../dataSource/topCrypto';


export class FavoritesPage extends Component {
    constructor() {
        super();
        this.state = {
            myFavorites: []
        }
    }


    render() {
        const { myFavorites } = this.state;

        return (
            <div>
                {myFavorites === [] ?
                    <div> <h3>Loading data...</h3> </div>
                    :
                    <div>
                        <h3>Your favorite crypto pairs</h3>
                        {myFavorites.map(crypto => (
                            <Card key={crypto.id} cryptoName={crypto.name} />
                        ))}
                    </div>
                }
            </div>
        )
    }

    componentDidMount() {
        const myFav = getCryptoList(topCrypto)

        this.setState({ myFavorites: myFav, })
    }
}

export default FavoritesPage
