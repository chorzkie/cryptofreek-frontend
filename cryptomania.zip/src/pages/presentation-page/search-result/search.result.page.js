import React, { Component } from 'react';
import Card from '../../../components/crypto-info/card.component';
import { getCryptoList } from '../presentation.utils';

import topCrypto from '../../../dataSource/topCrypto';


export class CryptoListPage extends Component {
    constructor() {
        super();
        this.state = {
            cryptoToView: []
        }
    }


    render() {
        const { cryptoToView } = this.state;

        return (
            <div>
                {cryptoToView === [] ?
                    <div> <h3>Loading data...</h3> </div>
                    :
                    <div>
                        {cryptoToView
                            .map(crypto => (
                                <Card key={crypto.id} cryptoName={crypto.name} />
                            ))}
                    </div>
                }
            </div>
        )
    }

    componentDidMount() {
        const top10 = getCryptoList(topCrypto)

        this.setState({ cryptoToView: top10, })
    }
}

export default CryptoListPage
