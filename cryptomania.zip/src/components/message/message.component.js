import React, { Component } from 'react'
import './message.styles.scss'


class Message extends Component {
    constructor() {
        super()
        this.state = {
            initMessage: 'Below are some of hottest crypto of the last 24 hrs...'
        }
    }

    render() {
        return (
            <div className='message'>
                {this.state.initMessage}
            </div>
        )
    }
}

export default Message;
