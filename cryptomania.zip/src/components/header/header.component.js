import React, { Component } from 'react'
import { Link } from 'react-router-dom'
import Logo from '../../assets/eos-eos-logo.svg'
import './header.styles.scss'

import SearchBar from './searchbar.component'



class Header extends Component {
    constructor() {
        super()

        this.state = {
            displayName: 'Dummy User',
            isLoggedin: true,
        }
    }

    render() {
        return (
            <div className='header'>
                <div className='website'>
                    <img
                        src={Logo}
                        className='logo'
                        alt="website logo"
                    />
                    <div className='the-name'>Cryptofreek</div>
                </div>


                <SearchBar />

                <div className='options'>

                    <div className='option1'>
                        <Link className='option1-child' to='/about'> Contact </Link>
                        {
                            this.state.isLoggedin ?
                                <div className='option1-child' onClick={() => console.log('signout')}> Sign Out </div>
                                :
                                <Link className='option1-child' to='/signin'> Sign In </Link>
                        }
                    </div>
                    <div className='option2'>
                        <div className='option2-child'>
                            {
                                this.state.isLoggedin ?
                                    <div> Hello, {this.state.displayName}! </div>
                                    :
                                    <div> Hi, please login! </div>
                            }
                        </div>
                        <Link className='option2-child' to='/favorites'> See Your Favorites </Link>

                    </div>
                </div>

            </div>
        )
    }

}

export default Header;