import React, { Component } from 'react'
import './searchbar.styles.scss'

import Forms from '../forms-and-buttons/forms.component'
import CustomButton from '../forms-and-buttons/button.component'



class SearchBar extends Component {
    constructor() {
        super()

        this.state = {
            searched: '',
        }
    }

    handleSubmit = async e => {
        e.preventDefault()
    }

    handleChange = (e) => {
        this.setState({ searched: e.target.value })
    }

    render() {
        return (
            <div >
                <form className='search-bar' onSubmit={this.handleSubmit}>
                    <Forms className='forms'
                        type="search"
                        placeholder="Search cryptocurrency"
                        value={this.state.searched}
                        handleChange={this.handleChange}
                    />
                    <CustomButton className='custom-button' type="submit"> <span role="img" aria-label="magnifying-glass">🔍</span> </CustomButton>
                </form>
            </div>
        )
    }
}

export default SearchBar;