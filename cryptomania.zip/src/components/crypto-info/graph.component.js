import React, { Component } from 'react';
import { Line } from 'react-chartjs-2';
import './graph.styles.scss';


class Graph extends Component {

    render() {
        const {graphData} = this.props;
        return (
            <div className='graph'>
                <Line
                    options={{
                        responsive: true,
                        legend: {
                            display: false
                        },
                        tooltips: {
                            mode: 'index',
                            intersect: false
                        },
                        hover: {
                            mode: 'index',
                            intersect: false
                        },
                        scales: {
                            xAxes: [{ display: false }],
                            yAxes: [{ display: false }]
                        }
                    }}
                    data={graphData}
                />
            </div>
        )
    }

    componentDidMount() {
        //setTimeout(() => fetchMinutelyData, 3600000);
    }

}

export default Graph;
