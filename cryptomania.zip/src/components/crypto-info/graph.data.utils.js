
export const dataLabel = () => {
    let newLabel = [];
    const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    for (let i = 24; i !== 0; i--) {
        const d = new Date()
        let labeltoPush = months[d.getMonth()] + ' ' + d.getDate() + ', ' + (d.getHours() < i ? d.getHours() + 24 - i : d.getHours() - i) + ' hrs'
        newLabel.push(labeltoPush)
    }

    return newLabel;
}

export const dataValue = (data24hr) => {
    if (data24hr.Response !== "Success") {
        return []
    }
    const valueOnly = data24hr.Data.Data.map(hourlyData => {
        return hourlyData.close
    })

    return valueOnly;
}

export const bckgrndColor = (data1min, data24hr) => {
    if (data1min.Response !== "Success") {
        return
    }
    if (data1min.Data.Data[1].close < data24hr.Data.Data[0].close) {
        return "#FF7B70"
    }
    else { return "#80FF9C" }
}

export const prctCount = (data1min, data24hr) => {
    if (data1min.Response !== "Success") {
        return
    }
    const prctChange = (data1min.Data.Data[1].close - data24hr.Data.Data[0].close) / data24hr.Data.Data[0].close * 100
    return prctChange.toFixed(2);
}