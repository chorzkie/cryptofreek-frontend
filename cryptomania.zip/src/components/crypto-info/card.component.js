import React, { Component } from 'react';
import Graph from './graph.component'
import Ticker from './ticker.component'
import CustomButton from '../forms-and-buttons/button.component'
import './card.styles.scss';




class Card extends Component {

    render() {
        const { cryptoName, isFavorite, lastPrice, prctChange, tickerColor, graphData } = this.props.details;

        return (
            <div className='card'>
                {graphData === [] ?
                    <div> <h3>Loading data...</h3> </div>
                    :
                    <div>
                        <Ticker cryptoName={cryptoName} lastPrice={lastPrice} tickerColor={tickerColor} prctChange={prctChange} />
                        <Graph graphData={graphData} />
                        <CustomButton className='custom-button' type="submit">
                            { isFavorite ? 'REMOVE FAVORITES' : 'ADD TO FAVORITES' }
                        </CustomButton>
                    </div>
                }
            </div>

        )
    }

    componentDidMount() {
    }
}


export default Card;
