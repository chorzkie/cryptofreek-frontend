import React, { Component } from 'react';
import { connect } from 'react-redux'
import {  getCryptoDetailsToPresentACT } from '../../redux/crypto-data/crypto.data.actions';

import './ticker.styles.scss';



const mapDispatchToProps = (dispatch) => {
    return {
        getCryptoDetailsToPresent: () => dispatch(getCryptoDetailsToPresentACT()),
    }
}

class Ticker extends Component {

    render() {
        const { cryptoName, lastPrice, tickerColor, prctChange } = this.props;

        return (
            <div className='ticker'>
                <div className='title'>{cryptoName} - USD</div>
                <div className='price'>
                    <div className='last-price'>$ {lastPrice}</div>
                    <div className={` ${(tickerColor === "#80FF9C") ? 'green' : 'red'} percent `}>
                        ( {prctChange} % )
                    </div>
                </div>
            </div>
        )
    }

    componentDidMount() {
        const { getCryptoDetailsToPresent } = this.props;
        
        setTimeout(() => getCryptoDetailsToPresent(), 60000);
    }

}

export default connect(null, mapDispatchToProps)(Ticker)